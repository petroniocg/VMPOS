/* 
 * reparation.c: Virtual Machine Placement Problem - Reparation Stage
 * Date: 17-11-2014
 * Author: Fabio Lopez Pires (flopezpires@gmail.com)
 * Corresponding Conference Paper: A Many-Objective Optimization Framework for Virtualized Datacenters
 */

/* include reparation stage header */
#include "reparation.h"
#include "commitment.h"
#include "common.h"

/* reparation: reparates the population
 * parameter: population matrix
 * parameter: physical machines matrix
 * parameter: virtual machines matrix
 * parameter: number of individuals
 * parameter: number of physical machines
 * parameter: number of virtual machines
 * returns: reparated population matrix
 */
int **reparation(int **population, int ***utilization, float **cm, int **H, int **V, int number_of_individuals, int h_size, int v_size, int CRITICAL_SERVICES)
{
	/* repairs population from not factible individuals */
	repair_population(population, utilization, cm, H, V, number_of_individuals, h_size, v_size, CRITICAL_SERVICES);
	return population;
}

/* repair_population: repairs population from not factible individuals
 * parameter: population matrix
 * parameter: utilization of the physical machines matrix
 * parameter: physical machines matrix
 * parameter: virtual machines matrix
 * parameter: number of individuals
 * parameter: number of physical machines
 * parameter: number of virtual machines
 * returns: nothing, it's void()
 */
void repair_population(int **population, int ***utilization, float **cm, int **H, int **V, int number_of_individuals, int h_size, int v_size, int CRITICAL_SERVICES)
{
	/* iterators */
	int iterator_individual = 0;
	int iterator_virtual = 0;
	int iterator_physical = 0;
	int factibility = 1;

	/* iterate on individuals */
	for (iterator_individual = 0; iterator_individual < number_of_individuals ; iterator_individual++)
	{
		/* every individual is feasible until it's probed other thing */		
		factibility = 1;
		/* constraint 2: Provision of VMs with Critical Services. Virtual machines with CRITICAL SERVICES have to be placed mandatorily */
		for (iterator_virtual = 0; iterator_virtual < v_size; iterator_virtual++)
		{
			if (V[iterator_virtual][3] == CRITICAL_SERVICES && population[iterator_individual][iterator_virtual] == 0)
			{
				factibility = 0;
				break;
			}
		}
		/* constraints 3-5: Resource capacity of physical machines. Iterate on physical machines */
		for (iterator_physical = 0; iterator_physical < h_size ; iterator_physical++)
		{
			// Petrônio: Checks whether the physical machine is being used
			if (cm[iterator_individual][iterator_physical] > 0.0)
				/* if any physical machine is overloaded on any resource, the individual is not factible */
				if (is_overloaded(H, utilization, cm, iterator_individual, iterator_physical))
				{
					factibility = 0;
					break;
				}
		}

		/* if the individual is not factible */
		if (factibility == 0)
		{
			repair_individual(population, utilization, cm, H, V, number_of_individuals, h_size, v_size, CRITICAL_SERVICES, iterator_individual);
		}
	}
}

/* repair_individual: repairs not factible individuals
 * parameter: population matrix
 * parameter: utilization of the physical machines matrix
 * parameter: physical machines matrix
 * parameter: virtual machines matrix
 * parameter: number of individuals
 * parameter: number of physical machines
 * parameter: number of virtual machines
 * parameter: identificator of the not factible individual to repair
 * returns: nothing, it's void()
 */
void repair_individual(int **population, int ***utilization, float **cm, int **H, int **V, int number_of_individuals, int h_size, int v_size, int CRITICAL_SERVICES, int individual)
{
	int iterator_virtual = 0;
	int iterator_virtual2 = 0;
	int iterator_virtual_again=0;
	int iterator_physical = 0;	
	/* every individual is not feasible until it's probed other thing */		
	int factibility = 0;
	/* id of a candidate physical machine for migration */
	int candidate = 0;
	/* a migration flag for overloaded physical machines indicating that a virtual machine was or not migrated yet */
	int migration = 0;
	/* iterate on each virtual machine to search for overloaded physical machines */

	float available_cpus = 0.0, available_memory = 0.0;

	//printf("\n\n\n******** ENTROU NO REPAIR INDIVIDUAL ***********\n");
	//printf("***** A SER REPARADO INDIVIDUO [ %d ]: **********\n\n", individual);
	//print_int_array_line(population[individual], v_size);

	for (iterator_virtual = 0; iterator_virtual < v_size; iterator_virtual++)
	{
		//printf("\n** individual: %d , iterador_virtual: %d **\n", individual, iterator_virtual);
		//printf("Primeiro IF testa se population[%d][%d] = %d eh != 0\n", individual, iterator_virtual, population[individual][iterator_virtual]);
		/* if the virtual machine was placed */
		if (population[individual][iterator_virtual] != 0)
		{
			migration = 0;
			/* verify is the physical machine assigned is overloaded in any physical resource */
			if ( is_overloaded(H, utilization, cm, individual, ( population[individual][iterator_virtual] - 1 )) )
			//*** PETRONIO: Como no IF anterior só pega valores diferentes de zero (VM está alocada), este -1
			//    desta linha vai indicar qual é a MF para testar com a função is_overloaded
			{
				//printf("** Esta Overloaded **\n");
				//printf("** Valor de (pop[%d][%d]-1) = %d ==> MF esta OVERLOADED **\n", individual, iterator_virtual, population[individual][iterator_virtual]-1);
				/* we search for a correct candidate for VM "migration" (it is not really a migration, only a physical machine change) */
				candidate = rand() % global_h_sizes[individual];
				//printf("\n** Candidato sorteado: %d **\n",candidate);
				for (iterator_physical=0; iterator_physical < global_h_sizes[individual]; iterator_physical++)
				{
					//printf("\n** Entrou no FOR: iterator_physical = %d E candidato = %d**\n", iterator_physical, candidate);

					// Caso a MF candidata não tenha VM alocada, o commitment vai ser 0, e não pode ser multiplicado pelos recursos de H
					// se o commitment for 1, o else resolve
					if (cm[individual][candidate] > 1.0)
					{
						available_cpus = (float) H[candidate][0] * cm[individual][candidate];
						available_memory = (float) H[candidate][1] * cm[individual][candidate];
					}
					else
					{
						available_cpus = (float) H[candidate][0];
						available_memory = (float) H[candidate][1];
					}
					if ( (float) utilization[individual][candidate][0] + (float) V[iterator_virtual][0] <= available_cpus &&
	   			   	 	 (float) utilization[individual][candidate][1] + (float) V[iterator_virtual][1] <= available_memory && 
						 (float) utilization[individual][candidate][2] + (float) V[iterator_virtual][2] <= (float) H[candidate][2] )
					{
						// **** PETRONIO ****
						//printf("** MF [%d] do Individuo [%d] pode assumir a demanda. **\n", candidate,individual);
						//printf("\nUtilizacao Original do Individuo [ %d ]\n", individual);
						//print_int_matrix(utilization[individual], h_size, 3);

						/* delete requirements from physical machine migration source */
						utilization[individual][population[individual][iterator_virtual]-1][0] -= V[iterator_virtual][0];
						utilization[individual][population[individual][iterator_virtual]-1][1] -= V[iterator_virtual][1];
						utilization[individual][population[individual][iterator_virtual]-1][2] -= V[iterator_virtual][2];

						/* add requirements from physical machine migration destination */
						utilization[individual][candidate][0] += V[iterator_virtual][0];
						utilization[individual][candidate][1] += V[iterator_virtual][1];
						utilization[individual][candidate][2] += V[iterator_virtual][2];

						// **** PETRONIO ****
						//printf("Alocado no candidato MF: %d, Nova Utiliz Individuo [ %d ]\n", candidate, individual);   // *** Petronio: utilização alterada
						//print_int_matrix(utilization[individual], h_size, 3); 
							// TEM QUE ARRUMAR O NUMERO DE INDIVÍDUOS (AS LINHAS) NA FUNÇÃO ACIMA. QUANDO É CHAMADA COM P, O VALOR É PASSADO
							// COM +1 PARA GERAR INDIVIDUO BASE, MAS QUANDO FOR COM Q, NÃO DEVE TER O +1

						/* refresh the population */
						population[individual][iterator_virtual] = candidate + 1;

						// **** PETRONIO ****
						//printf("\nPopulacao atualizada: population[%d][%d] = candidate + 1 = %d\n", individual, iterator_virtual, candidate + 1);
						//print_int_array_line(population[individual], v_size);

						// updte the commitment matrix
						update_commitment_line (population, cm, V, individual, h_size, v_size, CRITICAL_SERVICES);

						//printf("\n====> COMMITMENT LINE UPDATED  <=====\n [%d] ", individual);
						//print_float_array(cm[individual], h_size);

						
						/* virtual machine correctly "migrated" */
						migration = 1;
						break;
						/* Aqui tinha um erro, que consertei. Da forma que estava com o if e else
						   dentro das chaves, ele nunca seria executado por conta do break.
						   Vou colocá-los depois da chave que fecha o IF, mas ainda dentro do laço 
						*/
					}

					if (candidate < global_h_sizes[individual] - 1) //** Aqui estava com: candidate < h_size, e ele incrementava o candidato, mas não tem MF igual a h_size, tem que ser menor
					{
						candidate++;
					}
					else
					{
						candidate = 0;
					}
				}
				if (!migration)
				{
					if (V[iterator_virtual][3]!=CRITICAL_SERVICES)
					{
						//printf("\n** Nao teve Candidato, veio pro if de CRITICAL_SERVICES. E V[%d][3] eh diferente de de CRITICAL_SERVICES.**\n", iterator_virtual);
						/* delete requirements from physical machine migration source */
						utilization[individual][population[individual][iterator_virtual]-1][0] -= V[iterator_virtual][0];
						utilization[individual][population[individual][iterator_virtual]-1][1] -= V[iterator_virtual][1];
						utilization[individual][population[individual][iterator_virtual]-1][2] -= V[iterator_virtual][2];
						
						/* refresh the population */
						population[individual][iterator_virtual] = 0;

						// updte the commitment matrix
						update_commitment_line (population, cm, V, individual, h_size, v_size, CRITICAL_SERVICES);

						/* virtual machine correctly "deleted" */
						migration = 1;
						//break;
					}
				}
				if(!migration)
				{
					//printf("\n\n ============ XXXXXXXXXXXXXXXXX ====================\n\n");
					//printf("** Valor de (pop[%d][%d]-1) = %d ==> MF esta OVERLOADED **\n", individual, iterator_virtual, population[individual][iterator_virtual]-1);
					//printf("\nUtilizacao Original do Individuo [ %d ]\n", individual);
					//print_int_matrix(utilization[individual], h_size, 3);

					
					// Não migrou e se der break vai para o próximo indivíduo sem reparar o inidividuo atual
					// Então vou procurar se tem VM não crítica na mesma MF para desligar
					for (iterator_virtual2 = 0; iterator_virtual2 < v_size; iterator_virtual2++)
					{
						if ( population[individual][iterator_virtual2] == population[individual][iterator_virtual] &&
							 V[iterator_virtual2][3] != CRITICAL_SERVICES )
						{

							//printf("\n** Nao conseguiu migrar uma Critica. Vou desligar a VM: %d Nao Critica.**\n", iterator_virtual2);
							/* delete requirements from physical machine migration source */
							utilization[individual][population[individual][iterator_virtual]-1][0] -= V[iterator_virtual2][0];
							utilization[individual][population[individual][iterator_virtual]-1][1] -= V[iterator_virtual2][1];
							utilization[individual][population[individual][iterator_virtual]-1][2] -= V[iterator_virtual2][2];
							
							/* refresh the population */
							population[individual][iterator_virtual2] = 0;

							// updte the commitment matrix
							update_commitment_line (population, cm, V, individual, h_size, v_size, CRITICAL_SERVICES);

							/* virtual machine correctly "deleted" */
							migration = 1;

							//printf("Nova Utiliz Individuo [ %d ]\n", individual);
							//print_int_matrix(utilization[individual], h_size, 3); 

							if ( !is_overloaded(H, utilization, cm, individual, ( population[individual][iterator_virtual] - 1 )) )
								break;

						}
					}
					

					
					//break;
				}
			}
		}
	}

	//printf("\n\nSaindo da Reparacao do Individuo [%d] com:\n", individual);
	//print_int_array_line(population[individual], v_size);
}


// Função Modificada
int is_overloaded(int **H, int ***utilization, float **cm, int individual, int physical)
{
	// If the use of the VM exceeds the capacity of the physical machine return 1, otherwise return 0
	// Capacidade de CPU e de Memória multiplico e na Capacidade de Disco, não multiplico pelo comprometimento
	if ( ( (float) utilization[individual][physical][0] > (float) H[physical][0] * cm[individual][physical])
	||   ( (float) utilization[individual][physical][1] > (float) H[physical][1] * cm[individual][physical])
	||   ( (float) utilization[individual][physical][2] > (float) H[physical][2] ) )
	{
		return 1;
	}
	return 0;
}
