/* 
 * initialization.c: Virtual Machine Placement Problem - Initialization Stage
 * Date: 17-11-2014
 * Author: Fabio Lopez Pires (flopezpires@gmail.com)
 * Corresponding Conference Paper: A Many-Objective Optimization Framework for Virtualized Datacenters
 */

/* include initialization stage header */
#include "initialization.h"
#include "commitment.h"

/* initialization: initializes a population randomically
 * parameter: number of individuals
 * parameter: number of physical machines
 * parameter: number of virtual machines
 * parameter: virtual machines requirements matrix
 * returns: population matrix
 */

// *** INITIALIZATION QUE GERA ALEATORIAMENTE

int** initialization(int number_of_individuals, int h_size, int v_size, int **V, int CRITICAL_SERVICES)
{
	// population: initial population matrix 
	int **population = (int **) malloc (number_of_individuals *sizeof (int *));

	// iterators 
	int iterator_individual;
	int iterator_individual_position;

	// iterate on individuals 
	for (iterator_individual=0; iterator_individual < number_of_individuals; iterator_individual++)
	{
		population[iterator_individual] = (int *) malloc (v_size *sizeof (int));

		// iterate on positions of an individual 
		for (iterator_individual_position = 0; iterator_individual_position < v_size; iterator_individual_position++)
		{
			// individual with SLA != CRITICAL_SERVICES 
			if (V[iterator_individual_position][3] != CRITICAL_SERVICES)
			{
				// assign to each virtual machine a random generated physical machine 
				population[iterator_individual][iterator_individual_position] = generate_solution_position(h_size, 0);
			}
			// individual with SLA == CRITICAL_SERVICES 
			if (V[iterator_individual_position][3] == CRITICAL_SERVICES)
			{
				// assign to each virtual machine a random generated physical machine 
				population[iterator_individual][iterator_individual_position] = generate_solution_position(h_size, 1);
			}
		}
	}

	return population;
}



// *** INITIALIZATION QUE GERA VALORES FIXOS
/*
int** initialization(int number_of_individuals, int h_size, int v_size, int **V, int CRITICAL_SERVICES)
{
	// iterators 
	int iterator_individual;
	//int iterator_individual_position;

	// population: initial population matrix 
	int **population = (int **) malloc (number_of_individuals *sizeof (int *));

   	// alocando cada uma das linhas da matriz
   	for(iterator_individual = 0; iterator_individual < number_of_individuals; iterator_individual++)
   		population[iterator_individual] = (int *) malloc(v_size * sizeof(int));

	population[0][0] = 1;  // Era 0 no original, vou colocar 1 para ficar overloaded
	population[0][1] = 1;
	population[0][2] = 1;
	population[0][3] = 3;
	population[0][4] = 1;  // Era 0 no original, vou colocar 1 para ficar overloaded

	population[1][0] = 1;
	population[1][1] = 3;
	population[1][2] = 2;
	population[1][3] = 2;
	population[1][4] = 1;

	population[2][0] = 0;
	population[2][1] = 2;
	population[2][2] = 0;
	population[2][3] = 1;
	population[2][4] = 0;

	population[3][0] = 2;
	population[3][1] = 1;
	population[3][2] = 2;
	population[3][3] = 1;
	population[3][4] = 2;

	population[4][0] = 1;
	population[4][1] = 2;
	population[4][2] = 0;
	population[4][3] = 2;
	population[4][4] = 3;

	return population;
}
*/



/* generate_solution_position: generates a host number between 0 or 1 and parameter max_posible
 * parameter: maximun number for the randon number to return
 * parameter: SLA of the individual. for 1 the placement is mandatorly
 * returns: random number between 0 and parameter max_posible
 */
int generate_solution_position(int max_posible, int SLA)
{
	/* assign to each virtual machine a random generated physical machine from 0 to the maximum possible */
	if (SLA == 0)
	{
		/* integer from 0 to max_posible + 1*/
		return rand() % (max_posible + 1);
	} 
	/* assign to each virtual machine a random generated physical machine from 1 to the maximum possible */
	if (SLA == 1)
	{
		/* integer from 1 to max_posible */
		return rand() % max_posible + 1;
	} 
}
