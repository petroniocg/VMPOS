/* 
 * reparation.h: Virtual Machine Placement Problem - Reparation Stage Header
 * Date: 17-11-2014
 * Author: Fabio Lopez Pires (flopezpires@gmail.com)
 * Corresponding Conference Paper: A Many-Objective Optimization Framework for Virtualized Datacenters
 */

/* include libraries */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

//#define CL_CS 1  // Commitment Level for PMs with Critical Services
//#define CL_NC 2  // Commitment Level for PMs with No Critical services

extern int *global_h_sizes;

/* function headers definitions */
int** reparation(int ** population, int *** utilization, float **cm, int ** H, int ** V, int number_of_individuals, int h_size, int v_size, int CS);
void repair_population(int ** population, int *** utilization, float **cm, int ** H, int ** V, int number_of_individuals, int h_size, int v_size, int CS);
void repair_individual(int ** population, int *** utilization, float **cm, int ** H, int ** V, int number_of_individuals, int h_size, int v_size, int CS, int individual);
int is_overloaded(int **H, int ***utilization, float **cm, int individual, int physical);
//extern void update_commitment_line (int ** population, int **cm, int ** V, int individual_overloaded, int h_size, int v_size, int CRITICAL_SERVICES);
