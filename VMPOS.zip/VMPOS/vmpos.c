/* 
 * vmpos.c: Interactive Memetic Algorithm for Virtual Machine Placement with Over Subscription
 * Date: 18-04-2018
 * Author: Petrônio Carlos Bezerra (petroniocg@ifpb.edu.br)
 * This code is based in imavmp.c developed by Fabio Lopez Pires, as follows
 *
 * imavmp.c: Interactive Memetic Algorithm for Virtual Machine Placement (IMAVMP)
 * Date: 17-11-2014
 * Author: Fabio Lopez Pires (flopezpires@gmail.com)
 * Corresponding Conference Paper: A Many-Objective Optimization Framework for Virtualized Datacenters
 */


/* structure of a pareto element */
struct pareto_element{
	int *solution;
	float *costs;
	struct pareto_element *prev;
	struct pareto_element *next;
};

/* include libraries */
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

/* include own headers */
#include "common.h"
#include "initialization.h"
#include "commitment.h"
#include "reparation.h"
#include "local_search.h"
#include "variation.h"
#include "pareto.h"

#define SELECTION_PERCENT 0.5
#define CRITICAL_SERVICES 1 //Indicates if the VM run Critical Services

#define NUMBER_OF_PARAMETERS_PM 4
#define NUMBER_OF_PARAMETERS_VM 4

// The global variable to read informations from datacenter configuration file.
int total_of_individuals = 0;
int total_of_generations = 0;

float mc_cs; //Migration Cost of a VM with Critical Services
float mc_ncs; //Migration Cost of a VM with No Critical Services

float cl_cs = 0.0; // Commitment Level (CL) for PM hosting VMs with Critical Services (CS)
float cl_nc = 0.0; // Commitment Level (CL) for PM hosting VMs with NO Critical services (NC)

float energy_objective_weight = 0.0;
float dispersion_objective_weight = 0.0;
float migration_objective_weight = 0.0;


//* The global variable to control the evolution of the best solution
int generations_without_improvment = -1;  //When calculate the first best_individual, goes to zero
float global_best_individual_cost = BIG_COST;

int best_generation = 0;

int *global_best_individual;
float *global_best_objective_functions;

int *global_h_sizes;

int *base_solution;
int readed_solution = 0;

//Petronio: Nivel de Dispersao
int number_vms_sc = 0;

int generation;

/* main: Interactive Memetic Algorithm for Virtual Machine Placement with Over Subscription
 * parameter: path to the datacenter infrastructure file
 * returns: exit state
 */
int main (int argc, char *argv[]) {

    int m, iterator_virtual, iterator_physical;
	int pm_used_in_base_individual = 0;

	FILE *pareto_result;
	FILE *pareto_data;

    /* parameters verification */
	if (argc == 1)
	{
		/* wrong parameters */
		pareto_result = fopen("results/pareto_result","a");

		fprintf(pareto_result,"\n[ERROR] Usage: %s path_to_datacenter_file\n[ERROR] File not found. Check the writing, please.\n\n", argv[0]);

		fclose(pareto_result);
		/* finish him */
		return 1;
	}

    /* good parameters */	
	else
	{
		/* Interactive Memetic Algorithm previous stuff */

		/* number of generation, for iterative reference of generations */
		//int generation = 0;
		generation = 0;

		/* get the number of physical machines, virtual machines and network links from the datacenter infrastructure file (argv[1]) */
		int h_size = get_h_size(argv[1]); // ** Num of PMs **
		int v_size = get_v_size(argv[1]); // ** Num of VMs **

		pareto_result = fopen("results/pareto_result","a");
		fprintf(pareto_result,"\nDATACENTER CONFIGURATION:\nNum of PMs: h_size = %d,\nNum of VMs: v_size = %d",h_size,v_size);
		fclose(pareto_result);

		//pareto_data = fopen("results/pareto_result_data","a");
		//fprintf(pareto_data,"Energy\tDispersion\tMigration\tFitness\tGeneration\n");
		//fclose(pareto_data);

		global_best_individual = (int *) malloc ( v_size * sizeof (int) );

		for (iterator_virtual=0; iterator_virtual < v_size; iterator_virtual++)
			global_best_individual[iterator_virtual] = 0;

		global_best_objective_functions = (float *) malloc (3 *sizeof (float *));

		/* load physical machines resources, virtual machines requirements and network topology from the datacenter infrastructure file */
		int **H = load_H(h_size, argv[1]);
		//printf("\nH LOADED SUCCESSFULLY\n");// ** Só pra ver a função de print (commom.c). Como a matriz é 3x4, já passei os valores da função
		//print_int_matrix(H, h_size, NUMBER_OF_PARAMETERS_PM);

		int **V = load_V(v_size, argv[1], CRITICAL_SERVICES);
		//printf("\nV LOADED SUCCESSFULLY\n");
		//print_int_matrix(V, v_size, NUMBER_OF_PARAMETERS_VM);


		// load the configurations of the datacenter from vmpos_config_file
		load_dc_config();

		// Looks for a base solution in file
		//int *base_solution;
		if ( (readed_solution = read_base_solution(v_size) ) > 0 )
		{
			printf("\nBase Individual already exist and was readed, with %d VMs.\n", readed_solution);

			for (iterator_physical = 0; iterator_physical < h_size; iterator_physical++)
			{
				for (iterator_virtual=0; iterator_virtual < v_size; iterator_virtual++)
				{
					if (base_solution[iterator_virtual] == iterator_physical + 1)
					{
						pm_used_in_base_individual++;
						break;
					}
				}
			}

			global_h_sizes = (int*) malloc( total_of_individuals * sizeof(int) );

			for (iterator_physical = 0; iterator_physical < total_of_individuals; iterator_physical++)
			{
				global_h_sizes[iterator_physical] = pm_used_in_base_individual;
				//XXXX==>printf("%d\t", global_h_sizes[iterator_physical]);
			}

			//XXXX==>printf("\n /*/*/ BASE INDIVIDUL TO COMPARE IN COST OF MIGRATION OBJECTIVE /*/*/\n");
			//XXXX==>print_int_array_line (base_solution, v_size);
			//XXXX==>printf("\nNumero de PM usadas no Indiv Base: %d\n", pm_used_in_base_individual);

			//printf("\nH WITH SAME NUMBER OF PM AS IN BASE INDIVIDUAL\n");
			//print_int_matrix(H, h_size, NUMBER_OF_PARAMETERS_PM);
		}

		pareto_result = fopen("results/pareto_result","a");
		fprintf(pareto_result,"\nVMPOS CONFIGURATION PARAMETERS:\n");
		fprintf(pareto_result,"Number of Individuals: %d\nNumber of Generations: %d\n",total_of_individuals, total_of_generations);
		fprintf(pareto_result,"Energy Weight: %.3f\nDispersion Weight: %.3f\nMigration Weight: %.3f\n", energy_objective_weight, dispersion_objective_weight, migration_objective_weight);
		fprintf(pareto_result,"Commitment Level for PM with VMs with Critical Services: %.1f\nCommitment Level for PM with VMs with NO Critical Services: %.1f\n", cl_cs, cl_nc);
		fprintf(pareto_result,"Weights for VMs migrations: mc_cs = %.2f and mc_ncs = %.2f\n",mc_cs, mc_ncs);
		if ( readed_solution )
			fprintf(pareto_result,"Base Individual with %d VMs allocated in %d PM:\n", readed_solution, pm_used_in_base_individual);
		fclose(pareto_result);

		/* seed for rand() */
		srand((unsigned int) time(NULL));
		/* randon value of 0-1 */
		srand48(time(NULL));
		//-->printf("\nDATACENTER LOADED SUCCESSFULLY\n");
		//-->printf("\n*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*=*\n");

		/* Interactive Memetic Algorithm with Over Subscription starts here */

		/*******************************************/
		/* 01: Initialize population P_0 	   */
		/*******************************************/
		
		int **P;

		/* CM: Commitment Matrix. Has the level of commitment for each PM in each individal */
		float **CM;
		
		/* Additional task: load the utilization of physical machines of all individuals/solutions */
		int ***utilization_P;

		if ( !readed_solution )
		{
			// The last individuo (the +1 in first parameter) is the base solution that will be used to compare with other solution in migration cost objective
			P = initialization(total_of_individuals + 1, h_size, v_size, V, CRITICAL_SERVICES);
			//print_int_matrix(P, total_of_individuals + 1, v_size);

			base_solution = generate_base_solution(P, v_size, total_of_individuals);

			//print_int_array(base_solution, v_size);

			for (iterator_physical = 0; iterator_physical < h_size; iterator_physical++)
			{
				for (iterator_virtual=0; iterator_virtual < v_size; iterator_virtual++)
				{
					if (base_solution[iterator_virtual] == iterator_physical + 1)
					{
						pm_used_in_base_individual++;
						break;
					}
				}
			}

			global_h_sizes = (int*) malloc( (total_of_individuals+1) * sizeof(int) );

			for (iterator_physical = 0; iterator_physical < total_of_individuals+1; iterator_physical++)
			{
				global_h_sizes[iterator_physical] = pm_used_in_base_individual;
				//printf("PM[%d] = %d\t", iterator_physical, global_h_sizes[iterator_physical]);
			}

			//printf("\n");

			/* CM: Commitment Matrix. Has the level of commitment for each PM in each individal */
			CM = calculates_commitment(P, total_of_individuals + 1, h_size, v_size, V, CRITICAL_SERVICES);

			utilization_P = load_utilization(P, H, V, total_of_individuals + 1, h_size, v_size);

			//P = reparation(P, utilization_P, CM, H, V, total_of_individuals + 1, h_size, v_size, CRITICAL_SERVICES);
			repair_population(P, utilization_P, CM, H, V, total_of_individuals + 1, h_size, v_size, CRITICAL_SERVICES);

			//printf("\nBase individual repaired:\n");
			//print_int_array(base_solution, v_size);

		}
		else
		{
			P = initialization(total_of_individuals, pm_used_in_base_individual, v_size, V, CRITICAL_SERVICES);

			//XXXX==>printf("\nP_0 CREATED SUCCESSFULLY\n\n");
			//XXXX==>print_int_matrix(P, total_of_individuals, v_size); //** print_int_matrix(int **matrix, int rows, int columns)

			/* CM: Commitment Matrix. Has the level of commitment for each PM in each individal */
			CM = calculates_commitment(P, total_of_individuals, h_size, v_size, V, CRITICAL_SERVICES);

			//printf("\n====> COMMITMENT MATRIX INICIAL  <=====\n\n");		
			//print_float_matrix(CM, total_of_individuals, h_size);

			/* Additional task: load the utilization of physical machines of all individuals/solutions */
			utilization_P = load_utilization(P, H, V, total_of_individuals, h_size, v_size);
			//-->printf("\nP_0 UTILIZATION CALCULATED SUCCESSFULLY\n");

			// **** PETRONIO ****
			/*for (m=0; m < total_of_individuals; m++){   // *** Petronio: Só para mostrar a utilização de 5 individuos
			printf("\nUtilizacao Inicial das MFs na Solucao [ %d ]:\n", m);
			print_int_matrix(utilization_P[m], h_size, 3);
			}*/


			/************************************************/
			/* 02: P0’ = repair infeasible solutions of P_0 */
			/************************************************/
			//P = reparation(P, utilization_P, CM, H, V, total_of_individuals, pm_used_in_base_individual, v_size, CRITICAL_SERVICES);
			repair_population(P, utilization_P, CM, H, V, total_of_individuals,  pm_used_in_base_individual, v_size, CRITICAL_SERVICES);
			// Anderson
			// reparation(P, utilization_P, CM, H, V, total_of_individuals, pm_used_in_base_individual, v_size, CRITICAL_SERVICES);
			// P = reparation(utilization_P, CM, H, V, total_of_individuals, pm_used_in_base_individual, v_size, CRITICAL_SERVICES);
			//XXXX==>printf("\nP_0 REPAIRED SUCCESSFULLY\n");
			//XXXX==>print_int_matrix(P, total_of_individuals, v_size);

			//printf("\n====> COMMITMENT MATRIX AFTER REPAIRED P_0  <=====\n\n");		
			//print_float_matrix(CM, total_of_individuals, h_size);

			// **** PETRONIO ****
			/*for (m=0; m < total_of_individuals; m++){
				printf("\nUtilizacao das MFs Apos o Repair. Solucao [ %d ]:\n", m);
				print_int_matrix(utilization_P[m], h_size, 3);
			}*/
		}

		/******************************************************/
		/* 03: P0’’ = apply local search to solutions of P_0’ */
		/******************************************************/
		//if ( readed_solution )
			//P = local_search(P, utilization_P, CM, H, V, total_of_individuals, h_size, v_size, CRITICAL_SERVICES); //Old
			local_search(P, utilization_P, CM, H, V, total_of_individuals, h_size, v_size, CRITICAL_SERVICES);
		//else
			//P = local_search(P, utilization_P, CM, H, V, total_of_individuals, h_size, v_size, CRITICAL_SERVICES);		
		
		//XXXX==>printf("\n=====>>> P_0 AFTER LOCAL_SEARCH: <<<=====\n");
		//XXXX==>print_int_matrix(P, total_of_individuals, v_size);

		//printf("\n====> COMMITMENT MATRIX AFTER LOCAL_SEARCH  <=====\n\n");		
		//print_float_matrix(CM, total_of_individuals, h_size);

		// **** PETRONIO ****
		/*for (m=0; m < total_of_individuals; m++){
		   printf("\nUtilizacao das MFs Apos o Local Search. Solucao [ %d ]:\n", m);
		   print_int_matrix(utilization_P[m], h_size, 3);
		}*/

		/* Additional task: calculate the cost of each objective function for each solution */
		float **objectives_functions_P = load_objectives(P, utilization_P, CM, H, V, total_of_individuals, h_size, v_size, base_solution, CRITICAL_SERVICES);
		//XXXX==>printf("\nP_0 OBJECTIVE FUNCTIONS VALUES CALCULATED SUCCESSFULLY\n");

		//XXXX==>print_float_matrix(objectives_functions_P, total_of_individuals, 3);

		/* Additional task: calculate the non-dominated fronts according to NSGA-II */

		int *fronts_P = non_dominated_sorting(objectives_functions_P, total_of_individuals);
		//-->printf("\nP_0 NON-DOMINATED SORTING CALCULATED SUCCESSFULLY\n");
		//-->printf("POSICAO DOS INDIVIDUOS NA FRONTEIRAS EM P_0:\n");
		//-->print_int_array_line (fronts_P, total_of_individuals);


		/**********************************************************/
		/* 04: Update set of nondominated solutions Pc from P_0’’ */
		/**********************************************************/
		struct pareto_element *pareto_head = NULL;
		int iterator_individual;

		/* considering that the P_c is empty at first population, each non-dominated solution from first front is added */
		for (iterator_individual = 0 ; iterator_individual < total_of_individuals ; iterator_individual++)
		{
		 	if(fronts_P[iterator_individual] == 1)
		 	{
		 		pareto_head = (struct pareto_element *) pareto_insert(pareto_head,v_size,P[iterator_individual],objectives_functions_P[iterator_individual]);
				 
		 	}
		}
		
		//-->printf("\nP_KNOWN CALCULATED SUCCESSFULLY\n");

		//XXXX==>printf("\nP_%d PARETO FRONTS:\n", generation);
		//XXXX==>print_pareto_front (pareto_head, v_size);

		//-->fprintf(pareto_result,"\n *** GENERATION = %d ***", generation);

		//Só um teste. Esta linha não deve ficar aqui!!!
		report_best_population(pareto_head, H, V, v_size, h_size);
		//-->fclose(pareto_result);
		
		/* Additional task: identificators for the crossover parents */
		int father, mother;

		/* Additional task: structures for Q and PQ */
		int **Q;
		int ***utilization_Q;
		float **objectives_functions_Q;
		int *fronts_Q;

		/* CM_Q: Commitment Matrix of Q. Has the level of commitment for each PM in each individal */
		float **CM_Q;


		/* 07: While (stopping criterion is not met), do */
		//while (generation < total_of_generations && generations_without_improvment < 3)
		while (generation < total_of_generations )
		{
			//-->printf("\n\n/**********************************************************/\n");
			//-->printf("* GENERATION %d STARTED SUCCESSFULLY *\n",generation);
			//-->printf("/**********************************************************/\n");
			/* this is a new generation! */
			generation++;

			/*
			for (iterator_physical = 0; iterator_physical < total_of_individuals; iterator_physical++)
			{
				global_h_sizes[iterator_physical] = pm_used_in_base_individual;
				//printf("%d\t", global_h_sizes[iterator_physical]);
			}*/

		 	/* Additional task: Q is a random generated population, lets initialize it */
			Q = initialization(total_of_individuals, pm_used_in_base_individual, v_size, V, CRITICAL_SERVICES);

			//XXXX==>printf("\nQ CREATED SUCCESSFULLY\n\n");
			//XXXX==>print_int_matrix(Q, total_of_individuals, v_size);

			CM_Q = calculates_commitment(Q, total_of_individuals, h_size, v_size, V, CRITICAL_SERVICES);
			//printf("\n====> COMMITMENT MATRIX OF Q POPULATION  <=====\n\n");		
			//print_int_matrix(CM_Q, total_of_individuals, h_size);

			/* 08: Q_t = selection of solutions from P_t ∪ P_c */
			father = selection(fronts_P, total_of_individuals, SELECTION_PERCENT);
			mother = selection(fronts_P, total_of_individuals, SELECTION_PERCENT);

			//Notei que havia sorteio do mesmo indivíduo para pai e mãe. Vou alaterar.
			while (father == mother)
			{
				mother = selection(fronts_P, total_of_individuals, SELECTION_PERCENT);
			}

			//XXXX==>printf("\nSELECTION OF FATHER (%d) AND MATHER (%d) SUCCESSFULL\n", father, mother);

			/* 09: Q_t’ = crossover and mutation of solutions of Q_t */
			//Q = crossover(Q, father, mother, v_size); // Old
			crossover(Q, father, mother, v_size);
			//XXXX==>printf("\nCROSSOVER SUCCESSFULL:\n");
			//XXXX==>print_int_matrix(Q, total_of_individuals, v_size);

			/* 10: Q_t’ = crossover and mutation of solutions of Q_t */
			// Q = mutation(Q,V,total_of_individuals,h_size,v_size); // Old
			mutation(Q,V,total_of_individuals,h_size,v_size);
			//-->printf("\nMUTATION SUCCESSFULL:\n");
			//-->print_int_matrix(Q, total_of_individuals, v_size);

			/* Additional task: load the utilization of physical machines and network links of all individuals/solutions */
			utilization_Q = load_utilization(Q, H, V, total_of_individuals, h_size, v_size);
			//printf("\nP_%d UTILIZATION CALCULATED SUCCESSFULLY\n",generation);

			CM_Q = calculates_commitment(Q, total_of_individuals, h_size, v_size, V, CRITICAL_SERVICES);
			//printf("\n====> COMMITMENT MATRIX OF Q UPDATED  <=====\n\n");
			//print_int_matrix(CM_Q, total_of_individuals, h_size);

			/* 10: Q_t’’ = repair infeasible solutions of Q_t’ */
			Q = reparation(Q, utilization_Q, CM_Q, H, V, total_of_individuals, pm_used_in_base_individual, v_size, CRITICAL_SERVICES);
			//printf("\nQ_%d REPAIRED SUCCESSFULLY\n",generation);
			//print_int_matrix(Q, total_of_individuals, v_size);

			/* 11: Q_t’’’ = apply local search to solutions of Q_t’’ */
			//Q = local_search(Q, utilization_Q, CM_Q, H, V, total_of_individuals, h_size, v_size, CRITICAL_SERVICES); // Old
			local_search(Q, utilization_Q, CM_Q, H, V, total_of_individuals, h_size, v_size, CRITICAL_SERVICES);

			//XXXX==>printf("\nQ_%d AFTER LOCAL SEARCH\n",generation);
			//XXXX==>print_int_matrix(Q, total_of_individuals, v_size);

			/*for (m=0; m < total_of_individuals; m++){
				printf("\nUtilizacao das MFs Apos o Local Search [Q]. Solucao [ %d ]:\n", m);
				print_int_matrix(utilization_P[m], h_size, 3);
			}*/

			//-->printf("\n====> COMMITMENT MATRIX AFTER LOCAL SEARCH  <=====\n\n");		
			//-->print_int_matrix(CM_Q, total_of_individuals, h_size);

			/* Additional task: calculate the cost of each objective function for each solution */
			objectives_functions_Q = load_objectives(Q, utilization_Q, CM_Q, H, V, total_of_individuals, h_size, v_size, base_solution, CRITICAL_SERVICES);
			// printf("\nP_%d OBJECTIVE FUNCTIONS VALUES CALCULATED SUCCESSFULLY\n",generation);
			/* Additional task: calculate the non-dominated fronts according to NSGA-II */
			fronts_Q = non_dominated_sorting(objectives_functions_Q,total_of_individuals);
			//XXXX==>printf("\nQ_%d OBJECTIVE FUNCTIONS VALUES CALCULATED SUCCESSFULLY\n", generation);
			//XXXX==>print_float_matrix(objectives_functions_Q, total_of_individuals, 3);


			/* 12: Update set of nondominated solutions Pc from Qt’’’ */
			for (iterator_individual = 0 ; iterator_individual < total_of_individuals ; iterator_individual++)
		    {
			 	if(fronts_Q[iterator_individual] == 1)
			 	{
			 		pareto_head = (struct pareto_element *) pareto_insert(pareto_head,v_size,Q[iterator_individual],objectives_functions_Q[iterator_individual]);
					//print_pareto_front (pareto_head, v_size);
			 	}
			}
			
			//XXXX==>printf("\nP_KNOWN CALCULATED SUCCESSFULLY\n");
			//XXXX==>print_pareto_front (pareto_head, v_size);
			//-->printf("POSICAO DOS INDIVIDUOS NA FRONTEIRAS EM Q_%d:\n", generation);
			//-->print_int_array_line (fronts_Q, total_of_individuals);

			/* 17: Pt = fitness selection from Pt ∪ Qt’’’ */
			//P = population_evolution(P, Q, objectives_functions_P, objectives_functions_Q, fronts_P, total_of_individuals, v_size); // Old
			population_evolution(P, Q, objectives_functions_P, objectives_functions_Q, fronts_P, total_of_individuals, v_size);

			//XXXX==>printf("\nP_%d EVOLVED TO P_%d\n",generation-1,generation);
			//XXXX==>print_int_matrix(P, total_of_individuals, v_size);

			//-->pareto_result = fopen("results/pareto_result","a");
			//-->fprintf(pareto_result,"\n *** GENERATION = %d ***", generation);

			//Só um teste. Esta linha não deve ficar aqui!!!
			report_best_population(pareto_head, H, V, v_size, h_size);
			//-->fclose(pareto_result);
		}


		//report_best_population(pareto_head, H, V, v_size, h_size);
		//-->printf("\nTotal of Generations to Generate: %d\nActual Generation: %d\nWithout Enhance the Best: %d\n\n", total_of_generations, generation, generations_without_improvment);

		pareto_result = fopen("results/pareto_result","a");
		fprintf(pareto_result,"\nTotal of Generations to Generate: %d\nActual Generation: %d\nWithout Enhance the Best: %d\n\n", total_of_generations, generation, generations_without_improvment);
		fclose(pareto_result);

		/* finish him */

		//-->printf("\n /*/*/ BASE INDIVIDUL TO COMPARE IN COST OF MIGRATION OBJECTIVE /*/*/\n");
		//-->print_int_array_line (base_solution, v_size);

		free (global_best_individual);
		free (global_best_objective_functions);
		free (global_h_sizes);
		free_pareto_front (pareto_head);

		return 0;
	}
}

